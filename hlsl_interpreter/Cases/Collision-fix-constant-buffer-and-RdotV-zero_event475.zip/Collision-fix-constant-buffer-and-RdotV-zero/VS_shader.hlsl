// ---- Created with 3Dmigoto v1.2.45 on Tue Jun  2 17:01:04 2026

cbuffer MatrixBuffer : register(b0)
{
  float4x4 WorldViewProj : packoffset(c0);
  float4x4 World : packoffset(c4);
}

cbuffer LightBuffer : register(b1)
{
  float4 AmbientColor : packoffset(c0);
  float4 DiffuseColor : packoffset(c1);
  float4 SpecularColor : packoffset(c2);
  float3 LightPos : packoffset(c3);
  float LightRadius : packoffset(c3.w);
  float3 LightDir : packoffset(c4);
  float padding0 : packoffset(c4.w);
  float3 Attenuation : packoffset(c5);
  float padding1 : packoffset(c5.w);
  float OuterCone : packoffset(c6);
  float InnerCone : packoffset(c6.y);
}

cbuffer MaterialBuffer : register(b2)
{
  float4 MaterialDiffuseColor : packoffset(c0);
  float4 MaterialAmbientColor : packoffset(c1);
  float4 MaterialSpecularColor : packoffset(c2);
  float4 MaterialEmissiveColor : packoffset(c3);
  float Shininess : packoffset(c4);
  uint ColorMaterialMode : packoffset(c4.y);
  float2 Padding : packoffset(c4.z);
}

cbuffer CameraBuffer : register(b3)
{
  float3 cameraPos : packoffset(c0);
}



// 3Dmigoto declarations
#define cmp -
Texture1D<float4> IniParams : register(t120);
Texture2D<float4> StereoParams : register(t125);


void main( 
  float3 v0 : POSITION0,
  float3 v1 : NORMAL0,
  float4 v2 : COLOR0,
  float2 v3 : TEXCOORD0,
  out float4 o0 : SV_POSITION0,
  out float4 o1 : COLOR0,
  out float2 o2 : TEXCOORD0,
  out float2 p2 : TEXCOORD1,
  out float3 o3 : NORMAL0,
  out float3 o4 : WORLDPOS0)
{
  float4 r0,r1,r2;
  uint4 bitmask, uiDest;
  float4 fDest;

  r0.xyzw = WorldViewProj._m01_m11_m21_m31 * v0.yyyy;
  r0.xyzw = v0.xxxx * WorldViewProj._m00_m10_m20_m30 + r0.xyzw;
  r0.xyzw = v0.zzzz * WorldViewProj._m02_m12_m22_m32 + r0.xyzw;
  o0.xyzw = WorldViewProj._m03_m13_m23_m33 + r0.xyzw;
  r0.x = dot(v1.xyz, v1.xyz);
  r0.x = rsqrt(r0.x);
  r0.xyz = v1.xyz * r0.xxx;
  r1.x = dot(r0.xyz, World._m00_m10_m20);
  r1.y = dot(r0.xyz, World._m01_m11_m21);
  r1.z = dot(r0.xyz, World._m02_m12_m22);
  r0.x = dot(r1.xyz, r1.xyz);
  r0.x = rsqrt(r0.x);
  r0.xyz = r1.xyz * r0.xxx;
  r1.xyz = World._m01_m11_m21 * v0.yyy;
  r1.xyz = v0.xxx * World._m00_m10_m20 + r1.xyz;
  r1.xyz = v0.zzz * World._m02_m12_m22 + r1.xyz;
  r1.xyz = World._m03_m13_m23 + r1.xyz;
  r2.xyz = LightPos.xyz + -r1.xyz;
  o4.xyz = r1.xyz;
  r0.w = dot(r2.xyz, r2.xyz);
  r1.x = rsqrt(r0.w);
  r1.xyz = r2.xyz * r1.xxx;
  r1.w = dot(r0.xyz, r1.xyz);
  r2.x = r1.w + r1.w;
  r1.w = max(0, r1.w);
  r1.xyz = r0.xyz * -r2.xxx + r1.xyz;
  o3.xyz = r0.xyz;
  r0.x = dot(r1.xyz, cameraPos.xyz);
  r0.x = max(0, r0.x);
  r0.y = log2(r0.x);
  r0.x = cmp(0 < r0.x);
  r0.y = Shininess * r0.y;
  r0.y = exp2(r0.y);
  r2.xyzw = cmp(ColorMaterialMode == int4(1,5,2,3));
  r1.xyz = r2.www ? v2.xyz : MaterialSpecularColor.xyz;
  r2.xy = (int2)r2.yy | (int2)r2.xz;
  r1.xyz = SpecularColor.xyz * r1.xyz;
  r1.xyz = r1.xyz * r0.yyy;
  r0.xyz = r0.xxx ? r1.xyz : 0;
  r1.xyz = r2.xxx ? v2.xyz : MaterialDiffuseColor.xyz;
  r2.xyz = r2.yyy ? v2.xyz : MaterialAmbientColor.xyz;
  r1.xyz = DiffuseColor.xyz * r1.xyz;
  r1.xyz = r1.xyz * r1.www;
  r1.w = sqrt(r0.w);
  r2.w = Attenuation.y * r1.w + Attenuation.x;
  r1.w = cmp(LightRadius >= r1.w);
  r1.w = r1.w ? 1.000000 : 0;
  r0.w = r0.w * Attenuation.z + r2.w;
  r0.w = 1 / r0.w;
  r1.xyz = r1.xyz * r0.www;
  r1.xyz = r2.xyz * AmbientColor.xyz + r1.xyz;
  r0.xyz = r0.xyz * r0.www + r1.xyz;
  r0.w = cmp(ColorMaterialMode == 4);
  r1.xyz = r0.www ? v2.xyz : MaterialEmissiveColor.xyz;
  r0.xyz = r1.xyz + r0.xyz;
  o1.xyz = r0.xyz * r1.www;
  o1.w = 1;
  o2.xyzw = v3.xyxy;
  return;
}